(function () {
	'use strict';

	// 
	// 
	// 
	// 
	// Переменные 
	const body = document.querySelector('body');
	const html = document.querySelector('html');
	const popup = document.querySelectorAll('.popup');

	const headerTop = document.querySelector('.header-fixed') ? document.querySelector('.header-fixed') : document.querySelector('head');
	let fixedElements = document.querySelectorAll('[data-fixed]');
	let stickyObservers = new Map();

	const menuClass = '.header__mobile';
	const menu = document.querySelector(menuClass) ? document.querySelector(menuClass) : document.querySelector('head');
	const menuLink = document.querySelector('.menu-link') ? document.querySelector('.menu-link') : document.querySelector('head');
	const menuActive = 'active';

	const burgerMedia = 991;
	const bodyOpenModalClass = 'popup-show';

	let windowWidth = window.innerWidth;
	document.querySelector('.container').offsetWidth || 0;

	const checkWindowWidth = () => {
		windowWidth = window.innerWidth;
		document.querySelector('.container').offsetWidth || 0;
	};

	//
	//  
	//
	//
	// Проверки

	// Проверка на мобильное устройство
	function isMobile() {
		return /Android|webOS|iPhone|iPad|iPod|BlackBerry|BB|PlayBook|IEMobile|Windows Phone|Kindle|Silk|Opera Mini/i.test(navigator.userAgent)
	}

	// Проверка на десктоп разрешение 
	function isDesktop() {
		return windowWidth > burgerMedia
	}

	// Проверка поддержки webp 
	function checkWebp() {
		const webP = new Image();
		webP.onload = webP.onerror = function () {
			if (webP.height !== 2) {
				document.querySelectorAll('[style]').forEach(item => {
					const styleAttr = item.getAttribute('style');
					if (styleAttr.indexOf('background-image') === 0) {
						item.setAttribute('style', styleAttr.replace('.webp', '.jpg'));
					}
				});
			}
		};
		webP.src = "data:image/webp;base64,UklGRjoAAABXRUJQVlA4IC4AAACyAgCdASoCAAIALmk0mk0iIiIiIgBoSygABc6WWgAA/veff/0PP8bA//LwYAAA";
	}

	// Проверка на браузер safari
	const isSafari = /^((?!chrome|android).)*safari/i.test(navigator.userAgent);

	// Проверка есть ли скролл 
	function haveScroll() {
		return document.documentElement.scrollHeight !== document.documentElement.clientHeight
	}

	// Закрытие бургера на десктопе
	function checkBurgerAndMenu() {
		if (isDesktop()) {
			menuLink.classList.remove('active');
			if (menu) {
				menu.classList.remove(menuActive);
				if (!body.classList.contains(bodyOpenModalClass)) {
					body.classList.remove('no-scroll');
				}
			}
		}

		if (html.classList.contains('lg-on')) {
			if (isMobile()) {
				body.style.paddingRight = '0';
			} else {
				body.style.paddingRight = getScrollBarWidth() + 'px';
			}
		}
	}

	// Задержка при вызове функции. Выполняется в конце
	function debounce(fn, delay) {
		let timer;
		return () => {
			clearTimeout(timer);
			timer = setTimeout(() => fn.apply(this, arguments), delay);
		};
	}

	// Закрытие элемента при клике вне него
	function closeOutClick(closedElement, clickedButton, clickedButtonActiveClass, callback) {
		document.addEventListener('click', (e) => {
			const button = document.querySelector(clickedButton);
			const element = document.querySelector(closedElement);
			const withinBoundaries = e.composedPath().includes(element);

			if (!withinBoundaries && button?.classList.contains(clickedButtonActiveClass) && e.target !== button && !e.target.closest('.popup')) {
				button.click();
			}
		});
	}

	// Плавный скролл
	function scrollToSmoothly(pos, time = 400) {
		const currentPos = window.pageYOffset;
		let start = null;
		window.requestAnimationFrame(function step(currentTime) {
			start = !start ? currentTime : start;
			const progress = currentTime - start;
			if (currentPos < pos) {
				window.scrollTo(0, ((pos - currentPos) * progress / time) + currentPos);
			} else {
				window.scrollTo(0, currentPos - ((currentPos - pos) * progress / time));
			}
			if (progress < time) {
				window.requestAnimationFrame(step);
			} else {
				window.scrollTo(0, pos);
			}
		});
	}

	window.addEventListener('resize', debounce(checkWindowWidth, 100));


	//
	//
	//
	//
	// Позиционирование

	// Отступ элемента от краев страницы
	function offset(el) {
		var rect = el.getBoundingClientRect(),
			scrollLeft = window.pageXOffset || document.documentElement.scrollLeft,
			scrollTop = window.pageYOffset || document.documentElement.scrollTop;

		return {
			top: rect.top + scrollTop,
			left: rect.left + scrollLeft,
			right: windowWidth - rect.width - (rect.left + scrollLeft),
		}
	}


	// Добавление элементу обертки
	let wrap = (query, tag, wrapContent = false) => {
		let elements;

		let tagName = tag.split('.')[0] || 'div';
		let tagClass = tag.split('.').slice(1);
		tagClass = tagClass.length > 0 ? tagClass : [];

		{
			elements = document.querySelectorAll(query);
		}

		function createWrapElement(item) {
			let newElement = document.createElement(tagName);
			if (tagClass.length) {
				newElement.classList.add(...tagClass);
			}

			if (wrapContent) {
				while (item.firstChild) {
					newElement.appendChild(item.firstChild);
				}
				item.appendChild(newElement);
			} else {
				item.parentElement.insertBefore(newElement, item);
				newElement.appendChild(item);
			}
		}

		if (elements.length) {
			for (let i = 0; i < elements.length; i++) {
				createWrapElement(elements[i]);
			}
		} else {
			if (elements.parentElement) {
				createWrapElement(elements);
			}
		}
	};

	wrap('table', '.table');

	// Изменение ссылок в меню 
	if (!document.querySelector('body').classList.contains('home') && document.querySelector('body').classList.contains('wp')) {
		let menu = document.querySelectorAll('.menu li a');

		for (let i = 0; i < menu.length; i++) {
			if (menu[i].getAttribute('href').indexOf('#') > -1) {
				menu[i].setAttribute('href', '/' + menu[i].getAttribute('href'));
			}
		}
	}

	// Добавление класса loaded после полной загрузки страницы
	function loaded() {
		document.addEventListener('DOMContentLoaded', function () {
			html.classList.add('loaded');
			if (document.querySelector('header')) {
				document.querySelector('header').classList.add('loaded');
			}
			if (haveScroll()) {
				setTimeout(() => {
					html.classList.remove('scrollbar-auto');
				}, 500);
			}
		});
	}

	// Для локалки
	if (window.location.hostname == 'localhost' || window.location.hostname.includes('192.168')) {
		document.querySelectorAll('.logo, .crumbs>li:first-child>a').forEach(logo => {
			logo.setAttribute('href', '/');
		});

		document.querySelectorAll('.menu a').forEach(item => {
			let firstSlash = 0;
			let lastSlash = 0;

			if (item.href.split('/').length - 1 == 4) {
				for (let i = 0; i < item.href.length; i++) {
					if (item.href[i] == '/') {
						if (i > 6 && firstSlash == 0) {
							firstSlash = i;
							continue
						}

						if (i > 6 && lastSlash == 0) {
							lastSlash = i;
						}
					}
				}

				let newLink = '';
				let removeProjectName = '';

				for (let i = 0; i < item.href.length; i++) {
					if (i > firstSlash && i < lastSlash + 1) {
						removeProjectName += item.href[i];
					}
				}

				newLink = item.href.replace(removeProjectName, '');
				item.href = newLink;
			}
		});
	}

	// Расчет высоты шапки
	function setHeaderFixedHeight() {
		if (!headerTop) return;

		requestAnimationFrame(() => {
			const height = headerTop.offsetHeight;

			document.documentElement.style.setProperty('--headerFixedHeight', height + 'px');
		});
	}

	document.addEventListener('DOMContentLoaded', setHeaderFixedHeight);
	if (window.ResizeObserver) {
		const ro = new ResizeObserver(() => {
			setHeaderFixedHeight();
		});
		ro.observe(headerTop);
	}

	// Проверка на браузер safari
	if (isSafari) document.documentElement.classList.add('safari');

	// Проверка поддержки webp 
	checkWebp();

	// Закрытие бургера на десктопе
	window.addEventListener('resize', debounce(checkBurgerAndMenu, 100));
	checkBurgerAndMenu();

	// Добавление класса loaded при загрузке страницы
	loaded();

	// 
	// 
	// 
	// 
	// Функции для работы со скроллом и скроллбаром

	// Скрытие скроллбара
	function hideScrollbar() {
		// changeScrollbarGutter()

		popup.forEach(element => {
			element.style.display = 'none';
		});

		if (haveScroll()) {
			body.classList.add('no-scroll');
		}

		changeScrollbarPadding();
	}

	function showScrollbar() {
		if (!menu.classList.contains(menuActive)) {
			body.classList.remove('no-scroll');
		}

		changeScrollbarPadding(false);
	}

	// Ширина скроллбара
	function getScrollBarWidth$1() {
		let div = document.createElement('div');
		div.style.overflowY = 'scroll';
		div.style.width = '50px';
		div.style.height = '50px';
		document.body.append(div);
		let scrollWidth = div.offsetWidth - div.clientWidth;
		div.remove();

		if (haveScroll()) {
			return scrollWidth
		} else {
			return 0
		}
	}

	// Добавление полосы прокрутки
	function changeScrollbarGutter(add = true) {
		if (haveScroll()) {
			if (add) {
				body.classList.add(bodyOpenModalClass, 'scrollbar-auto');
				html.classList.add('scrollbar-auto');
			} else {
				body.classList.remove(bodyOpenModalClass, 'scrollbar-auto');
				html.classList.remove('scrollbar-auto');
			}
		}
	}

	// Добавление и удаление отступа у body и фиксированных элементов
	function changeScrollbarPadding(add = true) {
		const scrollbarPadding = getScrollBarWidth$1() + 'px';

		fixedElements.forEach(elem => {
			const position = window.getComputedStyle(elem).position;

			if (position === 'sticky') {
				if (add) {
					if (!stickyObservers.has(elem)) {
						const observer = new IntersectionObserver(([entry]) => {
							if (!entry.isIntersecting) {
								elem.style.paddingRight = scrollbarPadding;
							} else {
								elem.style.paddingRight = '0';
							}
						}, {
							threshold: [1]
						});
						observer.observe(elem);
						stickyObservers.set(elem, observer);
					}
				} else {
					elem.style.paddingRight = '0';
					const observer = stickyObservers.get(elem);
					if (observer) {
						observer.unobserve(elem);
						stickyObservers.delete(elem);
					}
				}
			} else {
				elem.style.paddingRight = add ? scrollbarPadding : '0';
			}
		});

		if (isSafari) {
			body.style.paddingRight = add ? scrollbarPadding : '0';
		}
	}

	// Изменение масштаба
	class ZoomDetector {
		constructor() {
			this.lastZoom = this.getCurrentZoom();
			this.isChecking = false;
			this.startDetection();
		}

		getCurrentZoom() {
			return window.outerWidth / window.innerWidth;
		}

		startDetection() {
			const checkZoom = () => {
				const currentZoom = this.getCurrentZoom();

				if (Math.abs(currentZoom - this.lastZoom) > 0.01) {
					this.lastZoom = currentZoom;
					this.onZoomChange(currentZoom);
				}

				if (this.isChecking) {
					requestAnimationFrame(checkZoom);
				}
			};

			this.isChecking = true;
			checkZoom();
		}

		stopDetection() {
			this.isChecking = false;
		}

		onZoomChange(zoomLevel) {
			const percentage = Math.round(zoomLevel * 100);
			// Отправка события
			window.dispatchEvent(new CustomEvent('zoomchange', {
				detail: { zoomLevel: percentage }
			}));
		}
	}

	new ZoomDetector();

	window.addEventListener('zoomchange', (e) => {
		if (haveScroll()) {
			changeScrollbarGutter(false);
		}
	});

	/* 
		================================================
		  
		Бургер
		
		================================================
	*/

	function burger() {
		if (menuLink) {
			let isAnimating = false;

			menuLink.addEventListener('click', function (e) {
				if (isAnimating) return
				isAnimating = true;

				menuLink.classList.toggle('active');
				menu.classList.toggle(menuActive);

				if (menu.classList.contains(menuActive)) {
					hideScrollbar();

					const scrollY = window.scrollY;
					headerTop.offsetHeight;

					if (scrollY === 0) {
						menu.style.removeProperty('top');
						// } else if (scrollY < headerHeight) {
						// 	menu.style.top = scrollY + 'px'
					} else {
						const headerRect = headerTop.getBoundingClientRect();
						menu.style.top = headerRect.bottom + 'px';
					}
				} else {
					setTimeout(() => {
						showScrollbar();
					}, 400);
				}

				setTimeout(() => {
					isAnimating = false;
				}, 500);
			});



			function checkHeaderOffset() {
				if (isMobile()) {
					changeScrollbarPadding(false);
				} else {
					if (body.classList.contains(bodyOpenModalClass)) {
						changeScrollbarPadding();
					}
				}

				if (isDesktop()) {
					menu.removeAttribute('style');

					if (!body.classList.contains(bodyOpenModalClass)) {
						body.classList.remove('no-scroll');

						if (isSafari) {
							changeScrollbarPadding(false);
						}
					}
				}
			}

			window.addEventListener('resize', debounce(checkHeaderOffset, 50));
			window.addEventListener('resize', debounce(checkHeaderOffset, 150));

			if (document.querySelector('.header__mobile')) {
				closeOutClick('.header__mobile', '.menu-link', 'active');
			}
		}
	}

	// Удаление хэша
	function removeHash() {
		setTimeout(() => {
			history.pushState("", document.title, window.location.pathname + window.location.search);
		}, 100);
	}

	/* 
		================================================
		  
		Плавная прокрутка
		
		================================================
	*/

	function scroll() {
		let headerScroll = 0;
		const scrollLinks = document.querySelectorAll('[data-scroll], .menu a');

		if (scrollLinks.length) {
			scrollLinks.forEach(link => {
				link.addEventListener('click', e => {
					const target = link.hash;

					if (target && target !== '#') {
						const scrollBlock = document.querySelector(target);
						e.preventDefault();

						if (scrollBlock) {
							headerScroll = (window.getComputedStyle(scrollBlock).paddingTop === '0px') ? -40 : 0;

							scrollToSmoothly(
								offset(scrollBlock).top - parseInt(headerTop.clientHeight - headerScroll),
								400
							);

							removeHash();
							menu.classList.remove(menuActive);
							menuLink.classList.remove('active');
							body.classList.remove('no-scroll');
						} else {
							let [baseUrl, hash] = link.href.split('#');
							if (window.location.href !== baseUrl && hash) {
								link.setAttribute('href', `${baseUrl}?link=${hash}`);
								window.location = link.getAttribute('href');
							}
						}
					}
				});
			});
		}

		document.addEventListener('DOMContentLoaded', () => {
			const urlParams = new URLSearchParams(window.location.search);
			const link = urlParams.get('link');

			if (link) {
				if (link.startsWith('tab-') && /^\d+-\d+$/.test(link.replace('tab-', ''))) {
					const [_, blockIndex, tabIndex] = link.split('-');
					const tabsBlock = document.querySelector(`[data-tabs-index="${blockIndex}"]`);
					const tabs = tabsBlock.querySelectorAll('[data-tabs-title]');

					if (tabs && tabs[tabIndex]) {
						tabs[tabIndex].click();

						scrollToSmoothly(
							offset(tabsBlock).top - parseInt(headerTop.clientHeight),
							400
						);
					}
				} else if (link.startsWith('tab-')) {
					const tabId = link;
					const tabButton = document.getElementById(tabId);

					if (tabButton) {
						tabButton.click();

						scrollToSmoothly(
							offset(tabButton.closest('[data-tabs]') || tabButton).top - parseInt(headerTop.clientHeight),
							400
						);
					}
				} else {
					const scrollBlock = document.getElementById(link);
					if (scrollBlock) {
						const headerScroll = (window.getComputedStyle(scrollBlock).paddingTop === '0px') ? -40 : 0;
						scrollToSmoothly(
							offset(scrollBlock).top - parseInt(headerTop.clientHeight - headerScroll),
							400
						);
					}
				}

				urlParams.delete('link');
				const newUrl = urlParams.toString() ?
					`${window.location.pathname}?${urlParams}` :
					window.location.pathname;
				window.history.replaceState({}, '', newUrl);
			}
		});
	}

	burger();
	scroll();

	//
	//
	//
	//
	// Общие скрипты

	// Добавление класса active при скролле
	document.addEventListener('DOMContentLoaded', () => {
		const sections = document.querySelectorAll('[id]');
		const menuLinks = document.querySelectorAll('.header__menu a');

		function onScroll() {
			let scrollPos = window.scrollY + window.innerHeight / 3;

			sections.forEach(section => {
				const top = section.offsetTop;
				const height = section.offsetHeight;
				const id = section.getAttribute('id');

				if (scrollPos >= top && scrollPos < top + height) {
					menuLinks.forEach(link => link.classList.remove('active'));
					const activeLink = document.querySelector('.header__menu a[href="#' + id + '"]');
					if (activeLink) activeLink.classList.add('active');
				}
			});
		}

		window.addEventListener('scroll', onScroll);
		onScroll();
	});




	// Анимация печатания 
	document.addEventListener('DOMContentLoaded', function () {
		var els = document.querySelectorAll('.js-typing');
		if (!els.length) return;

		els.forEach(function (el) {
			var html = el.dataset.typing || el.innerHTML;
			var speed = parseInt(el.dataset.speed, 10) || 50;

			var parser = new DOMParser();
			var doc = parser.parseFromString(html, 'text/html');
			var nodes = Array.from(doc.body.childNodes);

			function updateMinHeight() {
				var clone = el.cloneNode(true);
				clone.style.visibility = 'hidden';
				clone.style.position = 'absolute';
				clone.style.height = 'auto';
				clone.style.minHeight = '';
				clone.innerHTML = html;
				document.body.appendChild(clone);

				el.style.minHeight = el.scrollHeight + 'px';

				document.body.removeChild(clone);
			}

			var resizeTimer;
			window.addEventListener('resize', function () {
				clearTimeout(resizeTimer);
				resizeTimer = setTimeout(updateMinHeight, 50);
			});

			updateMinHeight();

			el.innerHTML = '';

			var caret = document.createElement('span');
			caret.className = 'typing-caret';
			caret.setAttribute('aria-hidden', 'true');
			el.appendChild(caret);

			var currentContainer = el;

			function typeNode(node, done) {
				if (node.nodeType === Node.TEXT_NODE) {
					var text = node.nodeValue;
					var i = 0;

					function typeChar() {
						if (i < text.length) {
							var ch = text.charAt(i);
							currentContainer.appendChild(document.createTextNode(ch));
							i++;

							if (ch !== ' ') {
								setTimeout(typeChar, speed);
							} else {
								typeChar();
							}
						} else {
							done();
						}
					}

					typeChar();
				} else if (node.nodeType === Node.ELEMENT_NODE) {
					var clone = document.createElement(node.tagName);

					Array.from(node.attributes).forEach(function (a) {
						clone.setAttribute(a.name, a.value);
					});

					el.insertBefore(clone, caret);

					var prev = currentContainer;
					currentContainer = clone;

					var children = Array.from(node.childNodes);
					var idx = 0;

					function nextChild() {
						if (idx < children.length) {
							typeNode(children[idx], function () {
								idx++;
								nextChild();
							});
						} else {
							currentContainer = prev;
							done();
						}
					}

					nextChild();
				} else {
					done();
				}
			}

			var idx = 0;

			function startTyping() {
				if (idx < nodes.length) {
					typeNode(nodes[idx], function () {
						idx++;
						startTyping();
					});
				}
			}

			startTyping();
		});
	});


	// Анимация фиксированной шапки для старых браузеров
	if (!CSS.supports("animation-timeline: scroll()")) {
		const header = document.querySelector('.header-fixed');

		window.addEventListener('scroll', () => {
			if (window.scrollY > 150) {
				header.classList.add('scrolled');
			} else {
				header.classList.remove('scrolled');
			}
		});
	}

})();
//# sourceMappingURL=script.js.map
